package com.mbyte.easy.common.entity;

import lombok.Data;

@Data
public class BaseEntity {
    private long id;
}
