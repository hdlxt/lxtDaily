package com.mbyte.easy.admin.mapper;

import com.mbyte.easy.admin.entity.Person;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *

 * @since 2019-04-05
 */
public interface PersonMapper extends BaseMapper<Person> {

}
