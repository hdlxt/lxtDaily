package com.mbyte.easy.admin.service;

import com.mbyte.easy.admin.entity.Person;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *

 * @since 2019-04-05
 */
public interface IPersonService extends IService<Person> {

}
